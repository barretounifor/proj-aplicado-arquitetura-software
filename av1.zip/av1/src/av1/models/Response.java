package av1.models;

public class Response {

	public int statusCode;
	
	public String message; 
	
	public Response(int statusCode, String message) {
		this.statusCode = statusCode;
		this.message = message;
	}
	
}

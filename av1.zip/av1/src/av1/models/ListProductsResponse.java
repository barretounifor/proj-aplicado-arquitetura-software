package av1.models;

import java.util.ArrayList;

public class ListProductsResponse extends Response {

	public ArrayList<Product> products;

	public ListProductsResponse(int statusCode, String message, ArrayList<Product> products) {
		super(statusCode, message);
		this.products = products;
	}
	

	
}

package av1;
import java.net.InetSocketAddress;
import java.io.IOException;
import java.io.OutputStream;
import com.sun.net.httpserver.HttpServer;

import av1.controllers.ProductController;
import av1.requestHandlers.ProductHandler;
import av1.services.ProductService;

public class Main {
	
	public static void main(String[] args) throws IOException {
		  HttpServer server = HttpServer.create(new InetSocketAddress(3337), 0);

		  ProductService productService = new ProductService();

	  	ProductController productController= new ProductController(productService);
			  	
	  
	  	var productsHandler = new ProductHandler(productController);
	  
	    server.createContext("/products", productsHandler);
 
		server.start();
		System.out.println("Servidor iniciado na porta 3337");
		System.out.println("Teste");
		
	}

}

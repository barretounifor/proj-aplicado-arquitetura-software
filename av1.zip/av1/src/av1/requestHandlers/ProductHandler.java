package av1.requestHandlers;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import org.json.JSONException;
import org.json.JSONObject;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import av1.controllers.ProductController;
import av1.models.Product;
import av1.models.Response;

public class ProductHandler implements HttpHandler {
  private ProductController productController;

  public ProductHandler(ProductController productController) {
    this.productController = productController;
  }

  public void handle(HttpExchange exchange) throws IOException {
	  try { 
	        InputStream input = exchange.getRequestBody();
 
	        BufferedReader reader = new BufferedReader(new InputStreamReader(input));
	        StringBuilder requestBody = new StringBuilder();
	        String line;
	        while ((line = reader.readLine()) != null) {
	            requestBody.append(line);
	        }
	      reader.close();
		  String path = exchange.getRequestURI().toString(); 
		  var product = parseProduct(requestBody.toString());
		  exchange.getResponseHeaders().set("Content-Type", "application/json");
		  OutputStream output = exchange.getResponseBody();
		    
    if (path.equals("/products")) {
      switch (exchange.getRequestMethod()) {
        case "POST":
          Response response1 = this.productController.createProduct(product);
          JSONObject json = new JSONObject(response1);
          exchange.sendResponseHeaders(response1.statusCode, -1);
          output.write(json.toString().getBytes());
          output.close();
          break;
        case "GET":
            Response response2 = productController.listProducts();
            JSONObject json1 = new JSONObject(response2);
            exchange.sendResponseHeaders(response2.statusCode, -1);
            output.write(json1.toString().getBytes());
            output.close();
            break;
        case "DELETE":
        	Response response3 = productController.deleteProductById(product.getId());
            JSONObject json3 = new JSONObject(response3);
            exchange.sendResponseHeaders(response3.statusCode, -1);
            output.write(json3.toString().getBytes());
            output.close();
            break;
        case "PUT":
        	Response response4 = productController.updateProductById(product);
            JSONObject json4 = new JSONObject(response4);
            exchange.sendResponseHeaders(response4.statusCode, -1);
            output.write(json4.toString().getBytes());
            output.close();
            break; 
        default:
          exchange.sendResponseHeaders(405, -1);
          exchange.close();
      }
    } else {
      exchange.sendResponseHeaders(404, -1);
      exchange.close();
    }
	  } catch(IOException err) {
		   exchange.sendResponseHeaders(500, -1);
	  }
  }

  private Product parseProduct(String json) throws JSONException { 

	  JSONObject obj = new JSONObject(json); 
	  Product product = new Product();
	  product.setId(obj.getInt("id"));
	  product.setName(obj.getString("name"));
	  product.setPrice(obj.getDouble("price"));
			  
	  return product;
	}
}
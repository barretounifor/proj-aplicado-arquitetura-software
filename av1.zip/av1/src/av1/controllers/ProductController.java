package av1.controllers;
import com.sun.net.httpserver.HttpExchange;

import av1.models.ListProductsResponse;
import av1.models.Product;
import av1.models.Response;
import av1.services.ProductService;

public class ProductController {

	private ProductService productService;
	
	public ProductController(ProductService productService) {
		this.productService = productService;
	}

	public Response createProduct(Product product){
	  Response response = productService.createProduct(product);
	  return response;
	}
	
	public ListProductsResponse listProducts() {
		return this.productService.listProducts();
	}
	
	public Response deleteProductById(int id) {
		return this.productService.deleteProductById(id);
	}
	
	public Response updateProductById( Product product) {
		return this.productService.updateProductById(product);
	}

	
}

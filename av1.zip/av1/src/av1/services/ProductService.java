package av1.services;

import java.util.ArrayList;

import av1.models.ListProductsResponse;
import av1.models.Product;
import av1.models.Response;

public class ProductService {
	
	ArrayList<Product> products = new ArrayList<Product>();
	
	public Response createProduct(Product product) {
		if (product.getPrice() <= 0 ) { 
			return new Response(400, "Insira um preço válido.");
		}

		if (product.getName().trim() == "") {
			return new Response(400, "Insira um nome válido.");
		}
		
		product.setId(this.products.size() + 1);
		
		this.products.add(product);
		
		return new Response(204, "Produto criado com sucesso.");
	}
	
	public ListProductsResponse listProducts() {
		return new ListProductsResponse(200,"Produtos recuperados com sucesso", this.products);
	}
	
	public Response deleteProductById(int id) {
		boolean productWasRemoved  = false;
		
		for (var i = 0; i < this.products.size(); i++) {
			if (this.products.get(i).getId() == id) {
				this.products.remove(i);
				productWasRemoved = true;
				break;
			}
		}
		
		if (!productWasRemoved) {
			return new Response(400, "Produto não encontrado.");
		}
		
		return new Response(200, "Produto removido com sucesso.");
	}

	public Response updateProductById(Product product) {
		boolean productWasUpdated  = false;
		
		if (product.getId() <= 0 ) {
			return new Response(400, "Id inválido.");
		}
		
		if (product.getPrice() <= 0 ) { 
			return new Response(400, "Insira um preço válido.");
		}

		if (product.getName().trim() == "") {
			return new Response(400, "Insira um nome válido.");
		}
		
		for (var i = 0; i < this.products.size(); i++) {
			if (this.products.get(i).getId() == product.getId()) {
				this.products.set(i,product);
				productWasUpdated = true;
				break;
			}
		}
		
		if (!productWasUpdated) {
			return new Response(400, "Produto não encontrado.");
		}
		
		return new Response(200, "Produto removido com sucesso.");
	}

	
}
